﻿using BoneLib;
using UnityEngine;
using MelonLoader;
public class HandToHeadDetection
{
    public static bool IsRightHandNearHead()
    {
        // Make sure the player's hands and head have been found
        if (Player.handsExist && Player.playerHead != null)
        {
            // Get the position of the right hand and the head
            Vector3 rightHandPosition = Player.rightHand.transform.position;
            Vector3 headPosition = Player.playerHead.position;

            // Check if the right hand is near the head by comparing their positions
            float proximityThreshold = 0.2f; // Define your own proximity threshold
            return Vector3.Distance(rightHandPosition, headPosition) <= proximityThreshold;
        }
        return false;
    }
}
