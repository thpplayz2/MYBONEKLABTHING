﻿using BoneLib.Notifications;
using MelonLoader;
public class HandToHeadNotification
{
    public static void CheckAndNotifyHandToHead()
    {
        if (HandToHeadDetection.IsRightHandNearHead())
        {
            // Create a notification with the desired message
            Notification notification = new Notification
            {
                Title = new NotificationText("Head Touch"),
                Message = new NotificationText("What did you really do this?")
            };

            // Send the notification
            Notifier.Send(notification);
        }
    }
}
